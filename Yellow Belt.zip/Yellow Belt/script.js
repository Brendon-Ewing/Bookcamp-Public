console.log("page loaded...")

//button 1
function hide(element) {
    element.remove();
}

var likeCount = [0,0,0];

function like(id) {
    likeCount[id]++;
    document.querySelector("#post-" + id).innerHTML = likeCount[id] + " Petter(s)";
}

function checkAlert(evt) {
    if (evt.target.value === "Cat") {
        alert('You are looking for a Cat');
    }
    if (evt.target.value === "Dog") {
        alert('You are looking for a Dog');
    }
}
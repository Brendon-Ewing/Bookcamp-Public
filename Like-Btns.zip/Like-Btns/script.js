console.log("page loading...");

// index     0  1   2
var likeCount = [9, 12, 9];

function like(id) {
    likeCount[id]++;
    document.querySelector("#post-" + id).innerHTML = likeCount[id] + "like(s)";
}
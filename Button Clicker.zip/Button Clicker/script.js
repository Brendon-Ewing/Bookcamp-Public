console.log("page loaded...")

function hide(element) {
    element.remove();
}

function message() {
    alert("Ninja was liked");
}

function login(element) {
    if(element.innerText == "Login") {
        element.innerText = "Logout";
    } else {
        element.innerText = "Login";
    }
}